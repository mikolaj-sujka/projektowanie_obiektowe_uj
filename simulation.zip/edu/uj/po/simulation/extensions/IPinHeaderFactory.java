package edu.uj.po.simulation.extensions;

public interface IPinHeaderFactory {
    int createOutputPinHeader(int size);
    int createInputPinHeader(int size);
}
